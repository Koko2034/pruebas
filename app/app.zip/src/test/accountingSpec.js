describe("#init", () => {
    describe("should return true", () => {
        it("when accountingService is equal to param", () => {
            accountingController.init(accountingService);
            expect(this.accountingService == accountingService).toBeTruthy();
        })
        it("when init is fill", () => {
           
            expect(accountingController.init != undefined).toBeTruthy();
        })

    })
    describe("should return false", () => {
        it("when accountingService is diferent to param", () => {
            accountingController.init(accountingService);
            expect(this.accountingService == "palabrasService").toBeFalsy();
        })
        it("when init is empty", () => {
           
            expect(accountingController.init === undefined).toBeFalsy();
        })

    })
});
describe("#valueElement",()=>{
    beforeEach(function () {
        var fixture = '<div class="field" id="fixture">' +
        ' <input id="prueba" value="2">'+
            '</div>';
        document.body.insertAdjacentHTML(
            'afterbegin',
            fixture);
    });
    afterEach(function () {
        document.body.removeChild(document.getElementById('fixture'));
    });
    describe("should return true", () => {
        it("when valueElement get Value correct", () => {
           expect(accountingController.valueElement("prueba") == 2).toBeTruthy();
        })
        it("when valueElement is fill", () => {
           const prueba = () =>{};
            expect(accountingController.valueElement != prueba).toBeTruthy();
        })

    })
    describe("should return false", () => {
        it("when valueElement get Value incorrect", () => {
            expect(accountingController.valueElement("prueba") != 2).toBeFalsy();
        })
        it("when valueElement is empty", () => {
            const prueba = () =>{};
            expect(accountingController.valueElement === prueba).toBeFalsy();
        })

    })
})
describe("#element",()=>{
    beforeEach(function () {
        var fixture = '<div class="field" id="fixture">' +
        ' <input id="prueba" value="2">'+
            '</div>';
        document.body.insertAdjacentHTML(
            'afterbegin',
            fixture);
    });
    afterEach(function () {
        document.body.removeChild(document.getElementById('fixture'));
    });
    describe("should return true", () => {
        it("when valueElement get Value correct", () => {
            let prueba = window.document.getElementById("prueba");
           expect(accountingController.element("prueba") == prueba).toBeTruthy();
        })
        it("when valueElement is fill", () => {
           const prueba = () =>{};
            expect(accountingController.element != prueba).toBeTruthy();
        })

    })
    describe("should return false", () => {
        it("when valueElement get Value incorrect", () => {
            let prueba = window.document.getElementById("prueba");
            expect(accountingController.element("prueba") != prueba).toBeFalsy();
        })
        it("when valueElement is empty", () => {
            const prueba = () =>{};
            expect(accountingController.element === prueba).toBeFalsy();
        })

    })
})
describe("#addpurchase", () => {
    beforeEach(function () {
        var fixture = '<div class="field" id="fixture">' +
            ' <input id="idMonitor" value="3">' +
            ' <input id="idMonitorPrice" value="50">' +
            ' <input id="idMonitorPurchase" value="0">' +
            ' <input id="idMonitorPurchasePrice" value="0">' +
            ' <input id="idTotal" value="0">' +
            '<input id="cantidadTotalSinComisiones" value="0">' +
            ' <input id="comision" value="0">' +
            ' <input id="totalInvoice" value="0">clear' +
            '</div>';
        document.body.insertAdjacentHTML(
            'afterbegin',
            fixture);
    });
    afterEach(function () {
        document.body.removeChild(document.getElementById('fixture'));
    });
    describe("should return true", () => {
        it("when addpurchase is fill", () => {
           
            expect(accountingController.addPurchase != undefined).toBeTruthy();
        })
        it("when addPurchase is empty", () => {
            const prueba = () =>{};
            expect(accountingController.addPurchase !== prueba).toBeTruthy();
        })
        it("when reset el value of id is equal 0",()=>{
            accountingController.init(accountingService);
            this.accountingService.init();
            accountingController.addPurchase("idMonitor");
            expect(window.document.getElementById("idMonitor").value == 0).toBeTruthy();
        })
        it("when reset el value of idPurchase is equal 3",()=>{
            accountingController.init(accountingService);
            this.accountingService.init();
            accountingController.addPurchase("idMonitor");
            expect(window.document.getElementById("idMonitorPurchase").value == 3).toBeTruthy();
        })
        it("when reset el value of idPurchasePrice is equal 150",()=>{
            accountingController.init(accountingService);
            this.accountingService.init();
            accountingController.addPurchase("idMonitor");
            expect(window.document.getElementById("idMonitorPurchasePrice").value  == 150).toBeTruthy();;
        })

    })
    describe("should return false", () => {
        it("when addPurchase is empty", () => {
            expect(accountingController.addPurchase === undefined).toBeFalsy();
        })
        it("when addPurchase is empty", () => {
            const prueba = () =>{};
            expect(accountingController.addPurchase === prueba).toBeFalsy();
        })
        it("when reset el value of id is diferent 0",()=>{
            accountingController.init(accountingService);
            this.accountingService.init();
            accountingController.addPurchase("idMonitor");
            expect(window.document.getElementById("idMonitor").value != 0).toBeFalsy();
        })
        it("when reset el value of idPurchase is diferent 3",()=>{
            accountingController.init(accountingService);
            this.accountingService.init();
            accountingController.addPurchase("idMonitor");
            expect(window.document.getElementById("idMonitorPurchase").value != 3).toBeFalsy();
        })
        it("when reset el value of idPurchasePrice is diferent 150",()=>{
            accountingController.init(accountingService);
            this.accountingService.init();
            accountingController.addPurchase("idMonitor");
            expect(window.document.getElementById("idMonitorPurchasePrice").value  != 150).toBeFalsy();;
        })


    })
})
describe("#deletePurchase", () => {
  
    beforeEach(function () {
        var fixture = '<div class="field" id="fixture">' +
        ' <input id="idMonitorPurchase" value="2">'+
        ' <input id="idMonitorPurchasePrice" value="300">'+
        ' <input id="idTotal" value="300">'+
        ' <input id="cantidadTotalSinComisiones" value="300">'+
        ' <input id="comision" value="300">'+
        ' <input id="totalInvoice" value="300">'+
            '</div>';
        document.body.insertAdjacentHTML(
            'afterbegin',
            fixture);
     
    });
    afterEach(function () {
        document.body.removeChild(document.getElementById('fixture'));
    });
    describe("should return true", () => {
        it("when deletePurchase is fill", () => {     
            expect(accountingController.deletePurchase != undefined).toBeTruthy();
        })
        it("when reset el value of idPurchase is equal 0",()=>{
            accountingController.init(accountingService);
            this.accountingService.init();
            accountingController.deletePurchase("idMonitorPurchase");
            expect(window.document.getElementById("idMonitorPurchase").value == 0).toBeTruthy();
        })
        it("when reset el value of idPurchasePrice is equal 0",()=>{
            accountingController.init(accountingService);
            this.accountingService.init();
            accountingController.deletePurchase("idMonitorPurchase");
            expect(window.document.getElementById("idMonitorPurchasePrice").value == 0).toBeTruthy();
        })

    })
    describe("should return false", () => {
        it("when deletePurchase is empty", () => {
           
            expect(accountingController.deletePurchase === undefined).toBeFalsy();
        })
        it("when reset el value of idPurchase is diferent 0",()=>{
            accountingController.init(accountingService);
            this.accountingService.init();
            accountingController.deletePurchase("idMonitorPurchase");
            expect(window.document.getElementById("idMonitorPurchase").value != 0).toBeFalsy();
        })
        it("when reset el value of idPurchasPrice is diferent 0",()=>{
            accountingController.init(accountingService);
            this.accountingService.init();
            accountingController.deletePurchase("idMonitorPurchase");
            expect(window.document.getElementById("idMonitorPurchasePrice").value != 0).toBeFalsy();
        })


    })
})
describe("#pay", () => {
    
    describe("should return true", () => {
        it("when pay is fill", () => {
            expect(accountingController.pay != undefined).toBeTruthy();
        })

    })
    describe("should return false", () => {
        it("when pay is empty", () => {
            expect(accountingController.pay === undefined).toBeFalsy();
        })

    })
})
describe("#calcuInvoice", () => {
    beforeEach(function () {
        var fixture = '<div class="field" id="fixture">' +
            ' <div id="idTotal"></div>' +
            ' <div id="cantidadTotalSinComisiones"></div>' +
            ' <div id="comision"></div>' +
            ' <div id="totalInvoice"></div>' +
            '</div>';
        document.body.insertAdjacentHTML(
            'afterbegin',
            fixture);
    });
    afterEach(function () {
        document.body.removeChild(document.getElementById('fixture'));
    });
    describe("should return true", () => {
        it("when calcuInvoice is fill", () => {
           const prueba = () =>{};
           expect(accountingController.calcuInvoice != prueba).toBeTruthy();
        })
        it("when execute change value of idTotal", () => {
            accountingController.init(accountingService);
            this.accountingService.init();
            this.accountingService.setInvoice(100);
            accountingController.calcuInvoice();
            expect(window.document.getElementById("idTotal").value== 100).toBeTruthy();

        })
        it("when execute change value of cantidadTotalSinComisiones", () => {
            accountingController.init(accountingService);
            this.accountingService.init();
            this.accountingService.setInvoice(100);
            accountingController.calcuInvoice();
            expect(window.document.getElementById("cantidadTotalSinComisiones").value == 100).toBeTruthy();
        })
        it("when execute change value of comision", () => {
            accountingController.init(accountingService);
            this.accountingService.init();
            this.accountingService.setInvoice(100);
            accountingController.calcuInvoice();
            expect(window.document.getElementById("comision").value == 2).toBeTruthy();
        })
        it("when execute change value of totalInvoice", () => {
            accountingController.init(accountingService);
            this.accountingService.init();
            this.accountingService.setInvoice(100);
            accountingController.calcuInvoice();
            expect(window.document.getElementById("totalInvoice").value == 102).toBeTruthy();
        })


    })
    describe("should return false", () => {
        it("when calcuInvoice is empty", () => {
            const prueba = () =>{};
            expect(accountingController.calcuInvoice == prueba).toBeFalsy();
        })
        it("when execute change error value of idTotal", () => {
            accountingController.init(accountingService);
            this.accountingService.init();
            this.accountingService.setInvoice(100);
            accountingController.calcuInvoice();
            expect(window.document.getElementById("idTotal").value!= 100).toBeFalsy();

        })
        it("when execute change value error of cantidadTotalSinComisiones", () => {
            accountingController.init(accountingService);
            this.accountingService.init();
            this.accountingService.setInvoice(100);
            accountingController.calcuInvoice();
            expect(window.document.getElementById("cantidadTotalSinComisiones").value != 100).toBeFalsy();
        })
        it("when execute change value error of comision", () => {
            accountingController.init(accountingService);
            this.accountingService.init();
            this.accountingService.setInvoice(100);
            accountingController.calcuInvoice();
            expect(window.document.getElementById("comision").value != 2).toBeFalsy();
        })
        it("when execute change value error  of totalInvoice", () => {
            accountingController.init(accountingService);
            this.accountingService.init();
            this.accountingService.setInvoice(100);
            accountingController.calcuInvoice();
            expect(window.document.getElementById("totalInvoice").value != 102).toBeFalsy();
        })


    })
})
describe("#changeSign", () => {
    describe("should return true", () => {
        it("when changeSign is fill", () => {
           const prueba = () =>{};
           expect(accountingController.changeSign != prueba).toBeTruthy();
        })
        it("when value is positive return negative",()=>{
            expect(accountingController.changeSign(4)<0).toBeTruthy();
        })
        it("when value is negative return positive",()=>{
            expect(accountingController.changeSign(-4)>0).toBeTruthy();
        })
        it("when value is 0 return 0",()=>{
            expect(accountingController.changeSign(0)==0).toBeTruthy();
        })
   })
    describe("should return false", () => {
        it("when changeSign is empty", () => {
            const prueba = () =>{};
            expect(accountingController.changeSign == prueba).toBeFalsy();
        })
        it("when value is positive return negative",()=>{
            expect(accountingController.changeSign(4)>0).toBeFalsy();
        })
        it("when value is negative return positive",()=>{
            expect(accountingController.changeSign(-4)<0).toBeFalsy();
        })
        it("when value is 0 return diferent 0",()=>{
            expect(accountingController.changeSign(0)!=0).toBeFalsy();
        })
       

    })
})