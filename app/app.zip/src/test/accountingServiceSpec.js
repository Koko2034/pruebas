describe("#init", () => {
    describe("should return true",()=>{
        it("when inicializate invoice is 0", () => {
            accountingService.init();
            expect(accountingService.getInvoice() == 0).toBeTruthy();
        })
        it("when inicializate totalInvoice is 0", () => {
            accountingService.init();
            expect(accountingService.getTotalInvoice() == 0).toBeTruthy();
        })
        it("when inicializate tax is 0", () => {
            accountingService.init();
            expect(accountingService.getTax() == 0).toBeTruthy();
        })
        it("when inicializate type is Transferencia_Bancaria", () => {
            accountingService.init();
            expect(accountingService.getType() == "Transferencia_Bancaria").toBeTruthy();
        })
        it("when init is fill",()=>{
            const prueba = () =>{};
            expect(accountingService.init != prueba).toBeTruthy();
        })
    })
    describe("should return false",()=>{
        it("when inicializate invoice is diferent 0", () => {
            accountingService.init();
            expect(accountingService.getInvoice() != 0).toBeFalsy();
        })
        it("when inicializate totalInvoice is diferent 0", () => {
            accountingService.init();
            expect(accountingService.getTotalInvoice() != 0).toBeFalsy();
        })
        it("when inicializate tax is diferent 0", () => {
            accountingService.init();
            expect(accountingService.getTax() != 0).toBeFalsy();
        })
        it("when inicializate type is diferent Transferencia_Bancaria", () => {
            accountingService.init();
            expect(accountingService.getType() != "Transferencia_Bancaria").toBeFalsy();
        })
        it("when init is empty",()=>{
            const prueba = () =>{};
            expect(accountingService.init == prueba).toBeFalsy();
        })
    })
});
describe("#add", () => {
    describe("should return true", () => {
        it("when two param are positive", () => {
            let param1 = 9;
            let param2 = 5;
            expect(accountingService.add(param1, param2) >= 0).toBeTruthy();
        })
        it("when two param1 es positive and equals than param2 who is negative", () => {
            let param1 = 9;
            let param2 = -9;
            expect(accountingService.add(param1, param2) == 0).toBeTruthy();
        })
        it("when param1 and param2 are negative", () => {
            let param1 = -9;
            let param2 = -9;
            expect(accountingService.add(param1, param2) < 0).toBeTruthy();
        })
        it("when param1 is positive and param2 is negative and is big than param1", () => {
            let param1 = 5;
            let param2 = -9;
            expect(accountingService.add(param1, param2) < 0).toBeTruthy();
        })
        it("when param1 is positive and param2 is negative and is little than param1", () => {
            let param1 = 5;
            let param2 = -4;
            expect(accountingService.add(param1, param2) > 0).toBeTruthy();
        })
        it("when param1 is negative and param2 is positive and is big than param1", () => {
            let param1 = -5;
            let param2 = 7;
            expect(accountingService.add(param1, param2) > 0).toBeTruthy();
        })
        it("when param1 is negative and param2 is positive and is little than param1", () => {
            let param1 = -5;
            let param2 = 3;
            expect(accountingService.add(param1, param2) < 0).toBeTruthy();
        })
        it("when add is fill", () => {
            const prueba = () => {};
            expect(accountingService.add !== prueba).toBeTruthy();
        })
        it("when add is fill",()=>{
            const prueba = () =>{};
            expect(accountingService.add != prueba).toBeTruthy();
        })

    });
    describe("should return false", () => {
        it("when two param are positive", () => {
            let param1 = 9;
            let param2 = 5;
            accountingService.add(param1, param2);
            expect(accountingService.add(param1, param2) < 0).toBeFalsy();
        })
        it("when two param1 es positive and equals than param2 who is negative", () => {
            let param1 = 9;
            let param2 = -9;
            expect(accountingService.add(param1, param2) != 0).toBeFalsy();
        })
        it("when param1 and param2 are negative", () => {
            let param1 = -9;
            let param2 = -9;
            expect(accountingService.add(param1, param2) >= 0).toBeFalsy();
        })
        it("when param1 is positive and param2 is negative and is big than param1", () => {
            let param1 = 5;
            let param2 = -9;
            expect(accountingService.add(param1, param2) > 0).toBeFalsy();
        })
        it("when param1 is positive and param2 is negative and is little than param1", () => {
            let param1 = 5;
            let param2 = -4;
            expect(accountingService.add(param1, param2) < 0).toBeFalsy();
        })
        it("when param1 is negative and param2 is positive and is big than param1", () => {
            let param1 = -5;
            let param2 = 7;
            expect(accountingService.add(param1, param2) < 0).toBeFalsy();
        })
        it("when param1 is negative and param2 is positive and is little than param1", () => {
            let param1 = -5;
            let param2 = 3;
            expect(accountingService.add(param1, param2) > 0).toBeFalsy();
        })
        it("when add is not empty", () => {
            const prueba = () => {};
            expect(accountingService.add === prueba).toBeFalsy();
        })
        it("when add is empty",()=>{
            const prueba = () =>{};
            expect(accountingService.add == prueba).toBeFalsy();
        })
    });
})
describe("#calcuPrice",()=>{
    describe("should return true",()=>{
        it("when calcuPrice is fill",()=>{
            const prueba = () =>{};
            expect(accountingService.calcuPrice != prueba).toBeTruthy();
        })
        it("when param1 and param2 is positive and !=0",()=>{
            let param1 = 4;
            let param2 = 5;
            expect(accountingService.calcuPrice(param1,param2)>0).toBeTruthy();
        })
        it("when param1 and param2 is positive and ==0",()=>{
            let param1 = 4;
            let param2 = 0;
            expect(accountingService.calcuPrice(param1,param2)==0).toBeTruthy();
        })
        it("when param1 is positive and param2 is negative and !=0",()=>{
            let param1 = 4;
            let param2 = -3;
            expect(accountingService.calcuPrice(param1,param2)<0).toBeTruthy();
        })
        it("when param1 is negative and param2 is positive and !=0",()=>{
            let param1 = -4;
            let param2 = 3;
            expect(accountingService.calcuPrice(param1,param2)<0).toBeTruthy();
        })
        it("when param1 is negative and param2 is negative and !=0",()=>{
            let param1 = -4;
            let param2 = -3;
            expect(accountingService.calcuPrice(param1,param2)>0).toBeTruthy();
        })

    })
    describe("should return false",()=>{
        it("when calcuPrice is empty",()=>{
            const prueba = () =>{};
            expect(accountingService.calcuPrice == prueba).toBeFalsy();
        })
        it("when param1 and param2 is positive and !=0",()=>{
            let param1 = 4;
            let param2 = 5;
            expect(accountingService.calcuPrice(param1,param2)<=0).toBeFalsy();
        })
        it("when param1 and param2 is positive and ==0",()=>{
            let param1 = 4;
            let param2 = 0;
            expect(accountingService.calcuPrice(param1,param2)!=0).toBeFalsy();
        })
        it("when param1 is positive and param2 is negative and !=0",()=>{
            let param1 = 4;
            let param2 = -3;
            expect(accountingService.calcuPrice(param1,param2)>=0).toBeFalsy();
        })
        it("when param1 is negative and param2 is positive and !=0",()=>{
            let param1 = -4;
            let param2 = 3;
            expect(accountingService.calcuPrice(param1,param2)>=0).toBeFalsy();
        })
        it("when param1 is negative and param2 is negative and !=0",()=>{
            let param1 = -4;
            let param2 = -3;
            expect(accountingService.calcuPrice(param1,param2)<=0).toBeFalsy();
        })
    })
})

describe("#getType",()=>{
    describe("should return true",()=>{
        it("when Type is equal to type assignation",()=>{
            accountingService.setType("Paypal");
            expect(accountingService.getType() == "Paypal").toBeTruthy();
        })
        it("when getType is fill",()=>{
            const prueba = () =>{};
            expect(accountingService.getType != prueba).toBeTruthy();
        })
     })
     describe("should return false",()=>{
        it("when Type is diferent to type assignation",()=>{
    
            accountingService.setType("Paypal");
            expect(accountingService.getType() != "Paypal").toBeFalsy();
        })
        it("when getType is empty",()=>{
            const prueba = () =>{};
            expect(accountingService.getType == prueba).toBeFalsy();
        })
     })
})
describe("#getInvoice",()=>{
    describe("should return true",()=>{
        it("when getInvoice is fill",()=>{
            const prueba = () =>{};
            expect(accountingService.getInvoice != prueba).toBeTruthy();
        })
        it("when Invoice is equal to assignation",()=>{
            accountingService.init();
            accountingService.setInvoice(100);
            expect(accountingService.getInvoice()==100).toBeTruthy();
        })
        it("when Invoice is equal to assignation",()=>{
            accountingService.init();
            accountingService.setInvoice(100);
            accountingService.setInvoice(200);
            expect(accountingService.getInvoice()==300).toBeTruthy();
        })
     })
     describe("should return false",()=>{
        it("when getInvoice is empty",()=>{
            const prueba = () =>{};
            expect(accountingService.getInvoice == prueba).toBeFalsy();
        })
        it("when Invoice is equal to assignation",()=>{
            accountingService.init();
            accountingService.setInvoice(100);
            expect(accountingService.getInvoice()!=100).toBeFalsy();
        })
        it("when Invoice is equal to assignation",()=>{
            accountingService.init();
            accountingService.setInvoice(100);
            accountingService.setInvoice(200);
            expect(accountingService.getInvoice()!=300).toBeFalsy();
        })

     })
})
describe("#getTotalInvoice",()=>{
    describe("should return true",()=>{
        it("when getTotalInvoice is fill",()=>{
            const prueba = () =>{};
            expect(accountingService.getTotalInvoice != prueba).toBeTruthy();
        })
        it("when Invoice is equal to assignation",()=>{
            accountingService.init();
            accountingService.setInvoice(100);
            accountingService.setTax();
            accountingService.setTotalInvoice();
            expect(accountingService.getTotalInvoice()==102).toBeTruthy();
        })
     })
     describe("should return false",()=>{
        it("when getTotalInvoice is empty",()=>{
            const prueba = () =>{};
            expect(accountingService.getTotalInvoice == prueba).toBeFalsy();
        })
        it("when Invoice is equal to assignation",()=>{
            accountingService.init();
            accountingService.setInvoice(100);
            accountingService.setTax();
            accountingService.setTotalInvoice();
            expect(accountingService.getTotalInvoice()!=102).toBeFalsy();
        })
     })
})
describe("#getTax",()=>{
    describe("should return true",()=>{
        it("when getTax is fill",()=>{
            const prueba = () =>{};
            expect(accountingService.getTax != prueba).toBeTruthy();
        })
        it("when tax is assignament",()=>{
            accountingService.init();
            accountingService.setInvoice(100);
            accountingService.setTax();
            expect(accountingService.getTax()==2).toBeTruthy();
        })
     })
     describe("should return false",()=>{
        it("when getTax is empty",()=>{
            const prueba = () =>{};
            expect(accountingService.getTax == prueba).toBeFalsy();
        })
        it("when tax is diferent assignament",()=>{
            accountingService.init();
            accountingService.setInvoice(100);
            accountingService.setTax();
            expect(accountingService.getTax()!=2).toBeFalsy();
        })
     })
})


describe("#setInvoice",()=>{
    describe("should return true",()=>{
        it("when setInvoice is fill",()=>{
            const prueba = () =>{};
            expect(accountingService.setInvoice != prueba).toBeTruthy();
        })
        it("when invoice is equal to assignament",()=>{
            accountingService.init();
            accountingService.setInvoice(100);
            expect(accountingService.getInvoice()==100).toBeTruthy();
        })
        it("when invoice is equal to assignament",()=>{
            accountingService.init();
            accountingService.setInvoice(100);
            accountingService.setInvoice(200);
            expect(accountingService.getInvoice()==300).toBeTruthy();
        })
     })
     describe("should return false",()=>{
        it("when setInvoice is empty",()=>{
            const prueba = () =>{};
            expect(accountingService.setInvoice == prueba).toBeFalsy();
        })
        it("when invoice is diferent to assignament",()=>{
            accountingService.init();
            accountingService.setInvoice(100);
            expect(accountingService.getInvoice() !=100).toBeFalsy();
        })
        it("when invoice is diferent to assignament",()=>{
            accountingService.init();
            accountingService.setInvoice(100);
            accountingService.setInvoice(200);
            expect(accountingService.getInvoice() !=300).toBeFalsy();
        })
     })
})
describe("#setTax",()=>{
    describe("should return true",()=>{
        it("when setTax is fill",()=>{
            const prueba = () =>{};
            expect(accountingService.setTax != prueba).toBeTruthy();
        })
        it("when setTax change good",()=>{
            accountingService.init();
            accountingService.setInvoice(100);
            accountingService.setTax();
            expect(accountingService.getTax()==2).toBeTruthy();
        })
        it("when setTax is correct",()=>{
            accountingService.init();
            accountingService.setInvoice(100);
            accountingService.setType("PayPal");
            accountingService.setTax();
            expect(parseFloat(accountingService.getTax())==3.75).toBeTruthy();
        })
     })
     describe("should return false",()=>{
        it("when setTax is empty",()=>{
            const prueba = () =>{};
            expect(accountingService.setTax == prueba).toBeFalsy();
        })
        it("when setTax is incorrect",()=>{
            accountingService.init();
            accountingService.setInvoice(100);
            accountingService.setType("PayPal");
            accountingService.setTax();
            expect(parseFloat(accountingService.getTax())!=3.75).toBeFalsy();
        })
     })
})

describe("#setTotalInvoice",()=>{
    describe("should return true",()=>{
        it("when getTotalInvoice is fill",()=>{
            const prueba = () =>{};
            expect(accountingService.getTotalInvoice != prueba).toBeTruthy();
        })
        it("when calcu de totalInvoice",()=>{
            accountingService.init();
            accountingService.setInvoice(200);
            accountingService.setTax();
            accountingService.setTotalInvoice();
            expect(accountingService.getTotalInvoice()==202).toBeTruthy();
        })
        it("when calcu de totalInvoice",()=>{
            accountingService.init();
            accountingService.setInvoice(200);
            accountingService.setType("PayPal"); 
            accountingService.setTax();
            accountingService.setTotalInvoice();
            expect(parseFloat(accountingService.getTotalInvoice())==207.15).toBeTruthy();
        })
     })
     describe("should return false",()=>{
        it("when setTotalInvoice is empty",()=>{
            const prueba = () =>{};
            expect(accountingService.setTotalInvoice == prueba).toBeFalsy();
        })
        it("when calcu de totalInvoice is error",()=>{
            accountingService.init();
            accountingService.setInvoice(200);
           accountingService.setTax();
            accountingService.setTotalInvoice();
            expect(accountingService.getTotalInvoice()!=202).toBeFalsy();
       
        })
        it("when calcu de totalInvoice",()=>{
            accountingService.init();
            accountingService.setInvoice(200);
            accountingService.setType("PayPal"); 
            accountingService.setTax();
            accountingService.setTotalInvoice();
            expect(parseFloat(accountingService.getTotalInvoice())!=207.15).toBeFalsy();
        })
     })
})
describe("#setType",()=>{
    describe("should return true",()=>{
        it("when setType is fill",()=>{
            const prueba = () =>{};
            expect(accountingService.setType != prueba).toBeTruthy();
        })
        it("when type is equal to assignament",()=>{
            accountingService.init();
            accountingService.setType("PayPal");
             expect(accountingService.getType()=="PayPal").toBeTruthy();
        })
       
     })
     describe("should return false",()=>{
        it("when setType is empty",()=>{
            const prueba = () =>{};
            expect(accountingService.setType == prueba).toBeFalsy();
        })
        it("when calcu de totalInvoice is error",()=>{
            accountingService.init();
           accountingService.setType("PayPal");
            expect(accountingService.getType()!="PayPal").toBeFalsy();
       
        })
       
     })
})

