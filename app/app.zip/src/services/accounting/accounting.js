const accountingController = ( function(platform){
    this.accountingService;

    const init = (accountingService) => {
        this.accountingService = accountingService;
        this.accountingService.init();
       
     }
    const valueElement  = (id) => platform.getElementById(id).value;
    const element = (id) => platform.getElementById(id);

    
    const addPurchase = (id) => {
        let cant = valueElement(`${id}`);
        let cantOri = valueElement(`${id}`+'Purchase');
        let cantAdd = this.accountingService.add(cant,cantOri);
        let price = valueElement(`${id}`+'Price');
        element(`${id}`+'Purchase').value = cantAdd;
        element(`${id}`).value=0;
        element(`${id}`+'PurchasePrice').value=this.accountingService.calcuPrice(cantAdd,price);
        this.accountingService.setInvoice(this.accountingService.calcuPrice(cant,price));
        calcuInvoice();
    }
    
    const deletePurchase = (id)=>{
        let elementPrice = element(`${id}`+'Price');
        element(`${id}`).value = 0;
        this.accountingService.setInvoice(parseInt(changeSign(elementPrice.value)));
        elementPrice.value=0;
        calcuInvoice();
    }
    const pay  = (value) =>{
           this.accountingService.setType(value);
           calcuInvoice();
           }
           const changeSign = (value) => -value;
    const calcuInvoice = () =>{
        element("idTotal").value=  this.accountingService.getInvoice();
        this.accountingService.setTax();
        this.accountingService.setTotalInvoice();
        element("cantidadTotalSinComisiones").value = this.accountingService.getInvoice();
        element("comision").value = this.accountingService.getTax();
        element("totalInvoice").value = this.accountingService.getTotalInvoice();
       
    }
    return{
        init,
        addPurchase,
        deletePurchase,
        pay,
        valueElement,
        element,
        calcuInvoice,
        changeSign
    }
})(window.document);