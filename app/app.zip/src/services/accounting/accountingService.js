const accountingService = ( function(){
    this.invoice;
    this.totalInvoice;
    this.tax;
    this.type;
    const methodPayment = {
        Transferencia_Bancaria :{
            fijo: 2,
            porcentaje:0,
        },
        PayPal:{
            fijo:0.35,
            porcentaje:3.4,
        },
        Tarjeta_credito :{
            fijo:1,
            porcentaje:1.9,
        },
    }
    
    const init = ()  =>{
        this.invoice=0;
        this.totalInvoice=0;
        this.tax=0;
        this.type="Transferencia_Bancaria";
     }

    const add = (param1,param2) => parseInt(param1)+parseInt(param2);
    const calcuPrice=(param1,param2) => parseInt(param1)*parseInt(param2);
   
    const getType = () => this.type;
    const getInvoice = () => this.invoice;
    const getTax = () => this.tax;
    const getTotalInvoice = () => this.totalInvoice;
    
    const setType = (param1)=>{
        this.type = param1;      
     }
    const setInvoice = (param1) =>{
        this.invoice=this.invoice+parseInt(param1);
       
     }
    const setTotalInvoice = () =>{
        this.totalInvoice = parseFloat(this.invoice)+parseFloat(this.tax);
     }
    
    const setTax = () => {
        this.tax = (methodPayment[getType()].fijo + ((methodPayment[getType()].porcentaje/100)*this.invoice)).toFixed(2);
       
     }
    
    return{
            init,
            add,
            calcuPrice,
            getInvoice,
            setInvoice,
            setType,
            getType,
            setTotalInvoice,
            getTotalInvoice,
            setTax,
            getTax
        }
    })();